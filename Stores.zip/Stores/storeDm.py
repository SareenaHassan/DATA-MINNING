# -*- coding: utf-8 -*-
"""
SAREENAAA
"""


import numpy as np
import pandas as pd 
import matplotlib.pyplot as plt
import seaborn as sns




df=pd.read_csv('Stores.csv')
df.head()

df.isnull().sum()

df.info()

df.Store_Area.unique()


df.columns

plt.figure(figsize=(6,6))

sns.scatterplot(x='Items_Available',y='Store_Area', data=df)

df1=df
df1.drop(['Store ID '],axis=1,inplace=True)
plt.figure(figsize=(6,6))
sns.pairplot(df1)

sns.boxplot(x=df1.Store_Sales)


int_cols = ['Store_Area', 'Items_Available', 'Daily_Customer_Count',
       'Store_Sales']


def data_outliers(x,fig):
    # subplot is used to plot multiple graph
    plt.subplot(2,2,fig)
    # title of the graph
    plt.title('Outliers of ' + x)
    # plot the graph
    sns.boxplot(x=df[x], palette=("Wistia"))
    plt.xticks(rotation= 90)
    
plt.figure(figsize=(12,6))

for e, i in enumerate(int_cols):
    data_outliers(i,e+1)



plt.tight_layout()
plt.show();